﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Nishy_Portfolio.Controllers
{
    public class PortController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult aboutmyself() { 
            return View();
        }
        public IActionResult skills()
        {
            return View();
        }
        public IActionResult acievements()
        {
            return View();
        }
        public IActionResult projects()
        {
            return View();
        }
    }
}